                         Bender.      

My third model, I'm just starting to learn how to use MILKSHAPE.

Bender is based around the Robot from Futurama.


    INSTALLATION:  UNZIP INTO  halflife\valve\models\player\Bender  folder



Feel free to distribute this .zip along with the README.txt

         FYA    MARQUIS   for skins (m.haly@cwcom.net) 26/10/99

Visit my skin site for some of the best skins with load of pictures of them in action.

         http://www.hlskins.free-online.co.uk/
