Skater


March 1, 2000
-------------------------------
bones       5164 bytes (35)
sequences 222660 bytes (1706 frames) [1:57]
vertices   11860 bytes (465 vertices, 447 normals)
mesh        9812 bytes (870 tris, 156 strips)
models     21860 bytes
textures   83620 bytes
total     333304
-------------------------------
Extract the files to half-life\valve\models\players\skater\.


Johannes Bill
jbill@gmx.net