Goofy HL is Property of Adrian Shephard adrien_shepard@hotmail.com.

Team Members: 

Adrian Shephard Job: Leader,Coder,Some Skinning,and other stuff.
Vash Job: Lead Mapper, Some Skinning, and other stuff.

-------------------------------------------------------------------------------
Are you bored with all these mods about realism? Ever just wanted to get frags in the goofiest way? If so, Goofy Half-Life is for you! But it doesnt Drop all the realism...there is just a bit left. Basically Goofy HL is just for fun. WARNING: If you are seeking a political career do NOT play this! If you should happen to catch a glimpse of any of this game, rinse eyes throughly 3 times with soap.


2/11/2004

------------------------------------------------

"Changes Beta 2.0"


added new ability walljump
added new Server CVARS
- Allow monsters in MP
- Gravity Limit
added HUD customization CVARs
added SinglePlayer Support
added new weapons
- M16
- M24 Sniper Rifle
- Q1 Axe
added new splash
added 31 new player models
added new maps
- ghl_boxing
- ghl_canyonduel
- ghl_hbpit
- ghl_quaint
- ghl_fiction
- ghl_hellfight
added commandmenu for quick use ingame
added and changed some more sprites
Updated
- ghl.fgd
- Crosshairs
fixed impulse code
fixed weapon selection bug
fixed reload times
fixed rpf frag count bug
fixed weapon damage
- M24
fixed weapon reload
- python
- shotgun
- glock
fixed secondary ammo bug
fixed flashlight bug
fixed weapon animtations
- uzi
changed SP models/skins
- Barney
- Human Grunts
- Scientists
- Garg
changed weapon firing rate
- 357
- Shotgun's Secondary Fire
changed hud color
changed Health and HEV charger capacity higher
changed hud design
changed forklift guys face
changed to hl.dll
changed weapon models/Skin
- uzi
- ak47
- shotgun
- MP5
changed rpf damage radius
changed "santa bomb" to "severed sci head bomb"
changed ammo capacity on more weapons.
changed Killer Gman stats
- more health
- longer lasting time

------------------------------------------------
12/23/2003

"Changes Beta 1.5"

added weapon Minigun
added weapon fists
added weapon uzi
added CS ak47 for CS fans :D
added fgd for mapping
added new map Noname
added Thirdperson view
added OICW zoom
added ghl.fgd
changed OICW ammo capacity
changed shotgun to shoot pellets with more spread
changed RPF to a RPG Nuke
changed all weapons Fire Underwater
changed map Mcdonalds (remake)
changed crossbow scope to 2x zoom
changed python scope 2x zoom
changed snark time to last longer
fixed sprites
fixed OICW
new player models
new splash
removed smokegrenade until it can be improved
removed Heart of Evil Shotgun (thanks for letting me use it)
removed new glock skin
removed gauss charge (actually did it this time)
changed "existences's" Killer Cellphones to killer gman (thanks for letting me use the phones)

------------------------------------------------

------------------------------------------------

"Changes Beta 1"

12/13/2003

Changes
added 15 new player models 
added New Weapon OICW 
added New Weapon Models (most of them atleast)  
change RPF to instant firing rockets 
changed non explosive crossbow 
added New glock skin 
added New Sprites for all weapons

------------------------------------------------

Credits & Special Thanks.


Hammy-Bob: For Beta Testing, some skins, and the map ghl_hbpit.
Vash: For Helping with maps and the vrobo skin, and hosting the new site.
Azzkiker: For hosting the files at  www.HL2Files.com
CheapAlert: For a little coding help
Matt: For the crazy sci model.
Garglet: For Goofy Recon and Mcdonalds worker model
Heart of Evil MOD: For letting me use their shotgun model in beta 1.
cHIs-wk: For Beta Testing and Hosting a server
aea: For hosting this mod on your site
Existence Team: For letting me use your Cellphone models in beta 1.
Weine: For oicw

To everyone else and all the fans Thank you.

If I'am Forgetting anyone let me know contact me at adrien_shepard@hotmail.com

--------------------------------------------------------

* Copyright *
"Goofy Half-Life" is �Adrian Shephard 2003-2004.
DO NOT Distribute this on any CD or anything without my consent.
If you just want to mirror it so other poeple can d/l it off your site, go right ahead, but keep all the files the same as in the .zip.